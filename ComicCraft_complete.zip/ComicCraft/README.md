# ComicCraft — AI Comic Story Creator

ComicCraft is a FastAPI web application that turns a user story prompt into a five-panel comic. It follows the project documentation's pipeline:

1. Gemini generates a structured five-panel outline.
2. Gemini expands the outline into narration and dialogue.
3. Hugging Face generates an illustration for each panel.
4. The layout builder combines panel data and images.
5. FPDF2 exports the complete comic to PDF.
6. Jinja2 renders the input and preview pages.

## Important implementation update

The supplied project document uses older `google-generativeai`, Gemini 1.5 model names, and local Diffusers/Stable Diffusion. This implementation keeps the documented architecture and five-panel workflow, but uses the current `google-genai` SDK and Hugging Face Inference Providers so image generation can run without requiring a local GPU.

## Quick start — Windows

```powershell
cd ComicCraft
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/docs

Health check: http://127.0.0.1:8000/health

## API

### POST /generate-comic/json

Example JSON:

```json
{
  "story_prompt": "A brave fox exploring an enchanted forest.",
  "character_name": "Luna",
  "setting": "Forest",
  "tone": "Funny",
  "art_style": "Comic book"
}
```

### GET /test-image

Example:

`/test-image?prompt=A%20friendly%20fox%20in%20a%20forest`

## Demo mode

`DEMO_MODE=true` runs the complete application without Gemini or Hugging Face. It creates deterministic placeholder panel images so you can test routes, templates, layout, and PDF export.

For real AI:
1. Put your Gemini API key in `GEMINI_API_KEY`.
2. Put your Hugging Face token in `HF_TOKEN`.
3. Set `DEMO_MODE=false`.
4. Restart Uvicorn.

## Testing

```powershell
pytest -q
```

## Project tree

```text
ComicCraft/
├── app/
│   ├── __init__.py
│   ├── config.py
│   ├── exporters.py
│   ├── gemini_flash.py
│   ├── gemini_pro.py
│   ├── image_generator.py
│   ├── layout_builder.py
│   ├── main.py
│   ├── models.py
│   └── routes.py
├── static/
│   ├── css/style.css
│   ├── panels/.gitkeep
│   └── exports/.gitkeep
├── templates/
│   ├── comic_preview.html
│   ├── export_success.html
│   └── index.html
├── tests/test_app.py
├── .env.example
├── .gitignore
├── README.md
└── requirements.txt
```
