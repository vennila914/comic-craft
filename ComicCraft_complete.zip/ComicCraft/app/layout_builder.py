from app.models import PanelStory

def build_comic_layout(stories, image_paths):
    return [
        {
            "panel_number": panel.panel_number,
            "title": panel.title,
            "image_path": image_paths[index],
            "scene_description": panel.scene_description,
            "caption": panel.caption,
            "narration": panel.narration,
            "dialogue": panel.dialogue,
            "image_prompt": panel.image_prompt,
        }
        for index, panel in enumerate(stories)
    ]
