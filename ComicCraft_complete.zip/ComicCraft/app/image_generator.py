import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from huggingface_hub import InferenceClient

from app.config import settings, PANELS_DIR

def _safe_name(text: str) -> str:
    value = re.sub(r"[^a-zA-Z0-9_-]+", "_", text).strip("_")
    return value[:50] or "panel"

def _demo_image(prompt: str, output_path: Path, panel_number: int):
    img = Image.new("RGB", (settings.image_width, settings.image_height), "white")
    draw = ImageDraw.Draw(img)
    draw.rectangle((24, 24, settings.image_width-24, settings.image_height-24), outline="black", width=8)
    font = ImageFont.load_default()
    text = f"COMICCRAFT\n\nPANEL {panel_number}\n\n{prompt[:300]}"
    draw.multiline_text((60, 100), text, fill="black", font=font, spacing=12)
    img.save(output_path, format="PNG")

def generate_image(prompt: str, panel_number: int) -> str:
    filename = f"panel_{panel_number}_{_safe_name(prompt)}.png"
    output_path = PANELS_DIR / filename

    if settings.demo_mode or not settings.hf_token:
        _demo_image(prompt, output_path, panel_number)
        return f"/static/panels/{filename}"

    client = InferenceClient(
        provider=settings.hf_provider,
        api_key=settings.hf_token,
    )
    enhanced = (
        f"{prompt}. Comic book panel composition, clear focal subject, expressive faces, "
        "cinematic lighting, clean linework, coherent environment, no text, no watermark."
    )
    image = client.text_to_image(
        prompt=enhanced,
        model=settings.hf_image_model,
    )
    image.save(output_path)
    return f"/static/panels/{filename}"
