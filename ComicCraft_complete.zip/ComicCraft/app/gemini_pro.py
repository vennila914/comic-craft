import json
from google import genai
from google.genai import types
from app.config import settings
from app.models import PanelOutline, PanelStory

def _demo_story(outlines, req):
    return [
        PanelStory(
            panel_number=p.panel_number,
            title=p.title,
            scene_description=p.scene_description,
            caption=f"{req.tone.title()} moment in {req.setting}.",
            narration=f"{req.character_name} takes the next step, staying focused despite the uncertainty.",
            dialogue=[f"{req.character_name}: We can figure this out together."],
            image_prompt=p.image_prompt,
        )
        for p in outlines
    ]

def generate_story(outlines, req):
    if settings.demo_mode or not settings.gemini_api_key:
        return _demo_story(outlines, req)

    client = genai.Client(api_key=settings.gemini_api_key)
    outline_json = [p.model_dump() for p in outlines]
    prompt = f"""
Expand this 5-panel comic outline into a polished comic story.

Story idea: {req.story_prompt}
Main character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Art style: {req.art_style}

Outline:
{json.dumps(outline_json, ensure_ascii=False)}

Return ONLY JSON:
{{
  "panels": [
    {{
      "panel_number": 1,
      "title": "...",
      "scene_description": "...",
      "caption": "...",
      "narration": "...",
      "dialogue": ["Character: ..."],
      "image_prompt": "..."
    }}
  ]
}}

Requirements:
- Exactly 5 panels in the same order.
- Dialogue must be short and natural.
- Keep character and visual continuity.
- No markdown fences.
"""
    response = client.models.generate_content(
        model=settings.gemini_pro_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema={
                "type": "OBJECT",
                "properties": {
                    "panels": {
                        "type": "ARRAY",
                        "items": {
                            "type": "OBJECT",
                            "properties": {
                                "panel_number": {"type": "INTEGER"},
                                "title": {"type": "STRING"},
                                "scene_description": {"type": "STRING"},
                                "caption": {"type": "STRING"},
                                "narration": {"type": "STRING"},
                                "dialogue": {"type": "ARRAY", "items": {"type": "STRING"}},
                                "image_prompt": {"type": "STRING"},
                            },
                            "required": [
                                "panel_number", "title", "scene_description",
                                "caption", "narration", "dialogue", "image_prompt"
                            ],
                        },
                    }
                },
                "required": ["panels"],
            },
        ),
    )
    data = json.loads(response.text)
    panels = [PanelStory.model_validate(p) for p in data["panels"]]
    if len(panels) != 5:
        raise ValueError("Gemini returned an invalid story panel count; expected exactly 5.")
    return panels
