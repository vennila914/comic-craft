import json
from google import genai
from google.genai import types
from app.config import settings
from app.models import PanelOutline

def _demo_outline(req):
    return [
        PanelOutline(
            panel_number=i,
            title=title,
            scene_description=desc,
            image_prompt=f"{req.art_style} comic panel, {desc}, starring {req.character_name}, setting: {req.setting}"
        )
        for i, (title, desc) in enumerate([
            ("The Beginning", f"{req.character_name} arrives in {req.setting} and notices something unusual."),
            ("A Strange Discovery", f"{req.character_name} follows a mysterious clue through {req.setting}."),
            ("The Challenge", f"{req.character_name} faces a surprising obstacle and decides to act bravely."),
            ("The Turning Point", f"{req.character_name} discovers a clever solution that changes the situation."),
            ("A New Dawn", f"{req.character_name} succeeds and leaves {req.setting} with a memorable lesson.")
        ], 1)
    ]

def generate_outline(req):
    if settings.demo_mode or not settings.gemini_api_key:
        return _demo_outline(req)

    client = genai.Client(api_key=settings.gemini_api_key)
    prompt = f"""
Create exactly 5 sequential comic panels.

User story idea: {req.story_prompt}
Main character: {req.character_name}
Setting: {req.setting}
Tone: {req.tone}
Art style: {req.art_style}

Return ONLY JSON matching this schema:
{{
  "panels": [
    {{
      "panel_number": 1,
      "title": "short title",
      "scene_description": "2-3 sentence scene description",
      "image_prompt": "detailed visual prompt for an image model"
    }}
  ]
}}

Requirements:
- Exactly 5 panels.
- Keep the same main character across all panels.
- Make the plot coherent from panel 1 to panel 5.
- Do not put dialogue in image_prompt.
- Avoid copyrighted characters or named living artists.
"""
    response = client.models.generate_content(
        model=settings.gemini_flash_model,
        contents=prompt,
        config=types.GenerateContentConfig(
            response_mime_type="application/json",
            response_schema={
                "type": "OBJECT",
                "properties": {
                    "panels": {
                        "type": "ARRAY",
                        "items": {
                            "type": "OBJECT",
                            "properties": {
                                "panel_number": {"type": "INTEGER"},
                                "title": {"type": "STRING"},
                                "scene_description": {"type": "STRING"},
                                "image_prompt": {"type": "STRING"},
                            },
                            "required": ["panel_number", "title", "scene_description", "image_prompt"],
                        },
                    }
                },
                "required": ["panels"],
            },
        ),
    )
    data = json.loads(response.text)
    panels = [PanelOutline.model_validate(p) for p in data["panels"]]
    if len(panels) != 5:
        raise ValueError("Gemini returned an invalid panel count; expected exactly 5.")
    return panels
