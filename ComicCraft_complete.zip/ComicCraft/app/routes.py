from pathlib import Path
from fastapi import APIRouter, Form, Request, HTTPException
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

from app.config import TEMPLATES_DIR
from app.models import PromptRequest
from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf

router = APIRouter()
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))

def run_pipeline(req: PromptRequest):
    outlines = generate_outline(req)
    stories = generate_story(outlines, req)
    image_paths = [generate_image(panel.image_prompt, panel.panel_number) for panel in stories]
    layout = build_comic_layout(stories, image_paths)
    pdf_url = save_pdf(layout, title=f"{req.character_name}'s Comic")
    return layout, pdf_url

@router.get("/")
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@router.post("/generate")
def generate(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    tone: str = Form(...),
    art_style: str = Form(...),
):
    try:
        req = PromptRequest(
            story_prompt=story_prompt,
            character_name=character_name,
            setting=setting,
            tone=tone,
            art_style=art_style,
        )
        layout, pdf_url = run_pipeline(req)
        return templates.TemplateResponse(
            "comic_preview.html",
            {"request": request, "layout": layout, "pdf_url": pdf_url, "character_name": character_name},
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}")

@router.post("/generate-comic/json")
def generate_json(req: PromptRequest):
    try:
        layout, pdf_url = run_pipeline(req)
        return {"character_name": req.character_name, "layout": layout, "pdf_url": pdf_url}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Comic generation failed: {exc}")

@router.get("/test-image")
def test_image(prompt: str = "A friendly fox in an enchanted forest, comic book art"):
    try:
        image_url = generate_image(prompt, 0)
        return {"image_url": image_url, "prompt": prompt}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Image generation failed: {exc}")

@router.get("/export-success")
def export_success(request: Request, pdf_url: str = ""):
    return templates.TemplateResponse(
        "export_success.html",
        {"request": request, "pdf_url": pdf_url},
    )
