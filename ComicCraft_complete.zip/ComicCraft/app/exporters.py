from datetime import datetime
from pathlib import Path
from fpdf import FPDF
from PIL import Image

from app.config import EXPORTS_DIR, STATIC_DIR

def _local_static_path(url_path: str) -> Path:
    relative = url_path.removeprefix("/static/")
    return STATIC_DIR / relative

def save_pdf(layout, title="ComicCraft Comic") -> str:
    filename = f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
    output = EXPORTS_DIR / filename

    pdf = FPDF("P", "mm", "A4")
    pdf.set_auto_page_break(auto=True, margin=15)

    for index, panel in enumerate(layout):
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['panel_number']}: {panel['title']}")
        pdf.ln(2)

        image_path = _local_static_path(panel["image_path"])
        if image_path.exists():
            with Image.open(image_path) as img:
                width, height = img.size
            max_w, max_h = 180, 115
            ratio = min(max_w / width, max_h / height)
            pdf.image(str(image_path), x=15, y=pdf.get_y(), w=width*ratio, h=height*ratio)
            pdf.ln(height*ratio + 5)

        pdf.set_font("Helvetica", "I", 10)
        pdf.multi_cell(0, 6, panel["scene_description"])
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Caption")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel["caption"])
        pdf.ln(2)

        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 6, "Narration")
        pdf.set_font("Helvetica", "", 11)
        pdf.multi_cell(0, 6, panel["narration"])
        if panel["dialogue"]:
            pdf.ln(2)
            pdf.set_font("Helvetica", "B", 11)
            pdf.multi_cell(0, 6, "Dialogue")
            pdf.set_font("Helvetica", "", 11)
            for line in panel["dialogue"]:
                pdf.multi_cell(0, 6, line)

    pdf.output(str(output))
    return f"/static/exports/{filename}"
