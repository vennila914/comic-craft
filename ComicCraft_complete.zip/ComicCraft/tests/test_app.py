from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_homepage():
    response = client.get("/")
    assert response.status_code == 200
    assert "ComicCraft" in response.text

def test_test_image():
    response = client.get("/test-image?prompt=Test%20fox")
    assert response.status_code == 200
    assert response.json()["image_url"].startswith("/static/panels/")
